function addBanner(){

    $("#bannerGroup").append("<li class='list-group-item'>Hello<button class='btn btn-danger btn-sm float-right delete'>X</button></li>");

}